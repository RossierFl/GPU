var searchData=
[
  ['release',['release',['../de/dd8/class_displayable___a.html#a0260d8a7e838cf679ca59626ced2bd7a',1,'Displayable_A']]],
  ['rendertext',['renderText',['../d4/dac/class_text_renderer___a.html#a861dfafa6cd2c16618067c58e8d2607f',1,'TextRenderer_A']]],
  ['reshape',['reshape',['../de/dd8/class_displayable___a.html#a068b4537a71ff4d0788e58d2b8f96e57',1,'Displayable_A']]]
];
