var searchData=
[
  ['textheight',['textHeight',['../d4/dac/class_text_renderer___a.html#a3f12373ee796ae6a7362955df2d1687d',1,'TextRenderer_A']]],
  ['textwidth',['textWidth',['../d4/dac/class_text_renderer___a.html#ad4f45625f1364524fabae7e9c9766eb8',1,'TextRenderer_A']]]
];
