var searchData=
[
  ['loadfont',['loadFont',['../d3/dad/class_font_loader___a.html#a926d7684f114724a75be596f9e2016c6',1,'FontLoader_A::loadFont(string fontName)=0'],['../d3/dad/class_font_loader___a.html#ae9af206da780b6e6291c7b2a46d74437',1,'FontLoader_A::loadFont(FontType type=HELVETICA_12)=0']]]
];
