var searchData=
[
  ['keyevent',['KeyEvent',['../df/d0c/class_key_event.html#a9787b1b5b91c6435241d13a533d2059f',1,'KeyEvent::KeyEvent(const Panel_A &amp;ptrPanelSource)'],['../df/d0c/class_key_event.html#a09aeda652f9f63bb40a179bd1cddd525',1,'KeyEvent::KeyEvent(const KeyEvent &amp;source)']]]
];
