var searchData=
[
  ['panel_5fa',['Panel_A',['../d1/d7e/class_panel___a.html',1,'']]]
];
