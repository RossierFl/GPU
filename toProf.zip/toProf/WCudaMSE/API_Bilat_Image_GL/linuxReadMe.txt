Avril 2012

**********************************
linux
**********************************

Les .so pour les api
	BilatImage
	BilatImageCuda
se trouve dans
	/usr/local/lib
	
Ces .so ne sont pas dans le workspace, car le rendu avec un bureau � distance pose alors probleme!	
	
*********************************
end
*********************************
	