#ifndef GLTOOLS_H
#define GLTOOLS_H

#include "envBilatGL.h"
#include "bilat_GL.h"

class CBI_GL GLTools
    {
    public:
	GLTools();
	virtual ~GLTools();

	static void openGL_Infos();
    };

#endif
