#ifndef RIPPLING_PROVIDER_H_
#define RIPPLING_PROVIDER_H_

#include "RipplingImage.h"

class RipplingProvider {
	public:

		static RipplingImage* create(void);

};

#endif

