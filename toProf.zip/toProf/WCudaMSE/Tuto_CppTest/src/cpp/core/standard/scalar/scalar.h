#ifndef SCALAR_H
#define SCALAR_H

double sum(double x1,double x2);
double fois(double x1,double x2);

#endif

/*----------------------------------------------------------------------*\
 |*			End	 					*|
 \*---------------------------------------------------------------------*/


