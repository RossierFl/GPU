#!/bin/bash
cbirt ./Histogramme.run
