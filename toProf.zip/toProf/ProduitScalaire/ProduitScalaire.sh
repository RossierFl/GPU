#!/bin/bash
cbirt ./ProduitScalaire.run
