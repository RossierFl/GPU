#!/bin/bash
cbirt gl ./Demo.run
