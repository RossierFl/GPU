#!/bin/bash
cbirt gl ./Newton.run
