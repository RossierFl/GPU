#!/bin/bash
cbirt ./MontecarloMultiGPU.run
