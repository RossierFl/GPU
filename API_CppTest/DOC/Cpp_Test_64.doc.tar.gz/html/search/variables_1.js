var searchData=
[
  ['tv_5fsec',['tv_sec',['../d9/d0e/struct_test_1_1timeval.html#aca8cda492ba177e613667cc1d78e06d4',1,'Test::timeval']]],
  ['tv_5fusec',['tv_usec',['../d9/d0e/struct_test_1_1timeval.html#a0d2f1f637ec31de63b2085cae7973e8a',1,'Test::timeval']]]
];
