var searchData=
[
  ['operator_2b',['operator+',['../dd/ded/class_test_1_1_time.html#ae2e555aa5b5c51e44b576d8baf48a2cd',1,'Test::Time']]],
  ['operator_2d',['operator-',['../dd/ded/class_test_1_1_time.html#a09225563b0b317910b26c550ba74de64',1,'Test::Time']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../dd/ded/class_test_1_1_time.html#a0287b008277738b9882ed96467e8b4f8',1,'Test::Time']]]
];
