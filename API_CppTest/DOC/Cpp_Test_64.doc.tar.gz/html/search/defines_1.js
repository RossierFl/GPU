var searchData=
[
  ['have_5fgettickcount',['HAVE_GETTICKCOUNT',['../d5/d1b/winconfig_8h.html#adb27b69ccc46cc0a84155775e0097f2f',1,'winconfig.h']]]
];
