var searchData=
[
  ['g',['g',['../db/d6f/class_color_char.html#a82e92e11f50c93bc4a86fee3a0ea32af',1,'ColorChar::g()'],['../dd/d01/class_colorf.html#a78a63e0f8a3e3c076b01dd8256124ad5',1,'Colorf::g()']]],
  ['green',['GREEN',['../db/d6f/class_color_char.html#ad26421f89f9dc5e9f4a046e0cb05bc52',1,'ColorChar::GREEN()'],['../dd/d01/class_colorf.html#ab0bd0f0089891a4ecffadcb978db2c2b',1,'Colorf::GREEN()']]]
];
