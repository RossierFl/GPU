var searchData=
[
  ['colorchar',['ColorChar',['../db/d6f/class_color_char.html',1,'']]],
  ['colorf',['Colorf',['../dd/d01/class_colorf.html',1,'']]]
];
