var searchData=
[
  ['b',['b',['../db/d6f/class_color_char.html#a37cbdf0df302dc9408e2b9802eb7e238',1,'ColorChar::b()'],['../dd/d01/class_colorf.html#a1b36e45d68f97229da79a61c390e3e52',1,'Colorf::b()']]],
  ['blue',['BLUE',['../db/d6f/class_color_char.html#a4d6de972a958db83f92576240d2a7521',1,'ColorChar::BLUE()'],['../dd/d01/class_colorf.html#ab44b01b43a13cfc27d5925d1d5eccf52',1,'Colorf::BLUE()']]],
  ['bufferid',['bufferID',['../dd/d5f/class_buffer_object.html#abe3852a7453dfdd08425e87981579915',1,'BufferObject']]]
];
