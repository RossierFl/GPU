var searchData=
[
  ['release',['release',['../da/de3/class_shader_programs.html#ae50313b56a0c9cb640b7195a8c236457',1,'ShaderPrograms::release()'],['../d2/d03/class_shaders.html#ad1a9670e2cc48aae20a7f64462de484e',1,'Shaders::release()']]],
  ['removeshader',['removeShader',['../da/de3/class_shader_programs.html#a5ea68c4a52775143aa7c1a3f70da028c',1,'ShaderPrograms']]]
];
