var searchData=
[
  ['colorchar',['ColorChar',['../db/d6f/class_color_char.html#a1db2e3d12bc7bd6bd90ba6f7e25ea931',1,'ColorChar']]],
  ['colorf',['Colorf',['../dd/d01/class_colorf.html#aef814f5bcd47e1b4b9644367f72f6e1b',1,'Colorf']]]
];
