var searchData=
[
  ['manganta',['MANGANTA',['../db/d6f/class_color_char.html#a6937d423102e52b4196568348afe5a2d',1,'ColorChar::MANGANTA()'],['../dd/d01/class_colorf.html#ac8702f3e5e265ee7547b9b41d43291f2',1,'Colorf::MANGANTA()']]]
];
